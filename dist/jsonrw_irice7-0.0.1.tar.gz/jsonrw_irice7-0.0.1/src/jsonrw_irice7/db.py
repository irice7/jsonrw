class Database:
    def __init__(self, db_path: str) -> None:
        pass

    def put(self, key: str, value: object) -> None:
        pass

    def get(self, key: str) -> object:
        pass

    def commit(self) -> None:
        pass

    def close(self) -> None:
        pass
